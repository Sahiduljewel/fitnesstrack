package oob.healthTrack;


public enum StepType {
    WALKING,
    JOGGING,
    RUNNING
}
