package oob.healthTrack.Domain.Maindomain.CheckUsernameStoredUseCase;

public interface CheckUsernameStoredUseCaseRepositoryInterface {
    boolean check();
}
