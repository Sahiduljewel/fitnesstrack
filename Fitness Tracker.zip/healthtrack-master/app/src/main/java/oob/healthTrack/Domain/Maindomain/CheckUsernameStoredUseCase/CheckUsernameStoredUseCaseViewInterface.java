package oob.healthTrack.Domain.Maindomain.CheckUsernameStoredUseCase;

import android.content.Context;

public interface CheckUsernameStoredUseCaseViewInterface {
    Context getContext();
}
